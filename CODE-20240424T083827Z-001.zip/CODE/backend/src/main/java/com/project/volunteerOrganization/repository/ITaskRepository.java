package com.project.volunteerOrganization.repository;

import com.project.volunteerOrganization.model.Organization;
import com.project.volunteerOrganization.model.Task;
import com.project.volunteerOrganization.model.Volunteer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ITaskRepository extends JpaRepository<Task, Long> {
    Task findByFilename(String filename);

    // Query Tasks based on Organization ID
    List<Task> findByOrganization_Id(Long organizationId);

    // Query Tasks based on Volunteer ID
    List<Task> findByVolunteer_Id(Long volunteerId);


    @Query(value = "SELECT DATE(created_at) AS created_date, COUNT(*) AS task_count\n" +
            "FROM task\n" +
            "WHERE volunteer_id = ?\n" + // Removed quotes around ?1
            "GROUP BY DATE(created_at)\n" +
            "ORDER BY created_date", nativeQuery = true)
    List<Object[]> findTaskCountByDateAndVolunteerId(Long volunteerId);

}
