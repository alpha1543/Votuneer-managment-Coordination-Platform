package com.project.volunteerOrganization.dao;

import java.time.LocalDateTime;

public interface Task
{
    LocalDateTime createdAt();
    Integer taskCount();
}
