package com.project.volunteerOrganization.dao;

import java.time.LocalDateTime;

public interface Chat
{
    Long id();
    Long sender();
    Long receiver();

    String message();

    LocalDateTime time();

}
