package com.project.volunteerOrganization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VolunteerOrganizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(VolunteerOrganizationApplication.class, args);
	}

}
