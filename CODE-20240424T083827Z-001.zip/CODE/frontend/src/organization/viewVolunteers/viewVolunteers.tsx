import "./viewVolunteers.css";
import { Header } from "../header/header";
import { api } from "../../utils/apiconfig";
import { useEffect, useRef, useState } from "react";
import { toast, Toaster } from "react-hot-toast";
export interface Volunteer {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: string;
}
export function Volunteers() {
  const [chat, setChat] = useState<any[]>([]);
  const [selectedVolunteer, setSelectedVolunteer] = useState<number>(0); // [1
  const message = useRef<HTMLInputElement>(null);
  const [volunteers, setVolunteers] = useState<Volunteer[]>([]);
  const fetchVolunteers = async () => {
    const response = await api.get("volunteer");
    // console.log(response.data, "data");
    setVolunteers(response.data.volunteers);
  };

  const fetchChat = async (reciver: number) => {
    try {
      const organization = JSON.parse(
        sessionStorage.getItem("organization") as string
      );
      const response = await api.get(`chat/message/${reciver}/${organization.id}`);
      console.log(response.data, "chat");
      setChat(response.data.msg);
    } catch (error) {
      toast.error("Failed to fetch chat");
    }
  };

  useEffect(() => {
    let mounted = true;
    if (mounted) {
      fetchVolunteers();
    }
    return () => {
      mounted = false;
    };
  }, []);
  return (
    <>
      <Header />
      <div className="container admin">
        <div
          className="h5 text-center"
          style={{
            marginTop: "60px",
          }}
        >
          View Volunteers
        </div>
        <div className="card mt-3">
          <div className="card-body">
            <table className="table table-bordered text-center">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Mobile</th>
                  <th>Address</th>
                  <th>Actions</th>
                  <th>Chat</th>
                </tr>
              </thead>
              <tbody>
                {volunteers.map((volunteer, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{volunteer.name}</td>
                    <td>{volunteer.email}</td>
                    <td>{volunteer.phone}</td>
                    <td>{volunteer.address}</td>
                    <td>
                      <button
                        className="btn btn-danger"
                        onClick={async () => {
                          const response = await api.delete(
                            `volunteer/${volunteer.id}`
                          );
                          if (response.status === 200) {
                            fetchVolunteers();
                            toast.success("Volunteer deleted successfully");
                          }
                        }}
                      >
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </td>
                    <td>
                        <button
                          className="btn btn-secondary"
                          type="button"
                          data-bs-toggle="modal"
                          data-bs-target="#chatModal"
                          onClick={() => {
                            setSelectedVolunteer(volunteer.id);
                            fetchChat(volunteer.id);
                          }}
                        >
                          <i className="fa-regular fa-comment"></i>
                        </button>
                      </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
        {/* chat modal */}
        <div
        className="modal fade"
        id="chatModal"
        tabIndex={-1}
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="exampleModalLabel">
                Chat with Volunteer
              </h1>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div
              className="modal-body"
              style={{
                height: "400px",
                overflowY: "scroll",
              }}
            >
              {chat.map((msg: any, index: number) => (
                <div
                style={{
                  marginTop: "50px"
                }}
                  key={index}
                  className={
                    msg.sender === selectedVolunteer
                      ? "text-start"
                      : "text-end"
                  }
                >
                  <span
                    className={
                      msg.sender === selectedVolunteer
                        ? "badge bg-primary"
                        : "badge bg-secondary"
                    }
                  >
                    {msg.sender === selectedVolunteer
                      ?"Volunteer"
                      :"Organization" }
                  </span>
                  <p
                  
                    className={
                      msg.sender === selectedVolunteer
                        ? "alert alert-primary d-inline"
                        : "alert alert-secondary d-inline"
                    }
                  >
                    {msg.message}
                  </p>
                </div>
              ))}
            </div>
            <div className="modal-footer">
              <input
                ref={message}
                type="text"
                className="form-control"
                placeholder="Message"
              />
              <button
                type="button"
                className="btn btn-primary"
                onClick={async () => {
                  console.log(message.current?.value);
                  const organization = JSON.parse(
                    sessionStorage.getItem("organization") as string
                  );
                  const dataToSend = {
                    message: message.current?.value,
                    sender: organization.id,
                    receiver: selectedVolunteer,
                  };
                  try {
                    await api.post("chat", dataToSend);
                    toast.success("Message sent successfully");
                    message.current!.value = "";
                   
                  } catch (error) {
                    toast.error("Failed to send message");
                  }
                  // message.current!.value = "";
                }}
              >
                Send
              </button>
            </div>
          </div>
        </div>
      </div>
      <Toaster />
    </>
  );
}
