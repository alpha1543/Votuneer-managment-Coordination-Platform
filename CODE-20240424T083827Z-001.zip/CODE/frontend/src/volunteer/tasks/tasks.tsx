import "./tasks.css";
import { Header } from "../header/header";
import { useState, useEffect } from "react";
import toast, { Toaster } from "react-hot-toast";

import { api } from "../../utils/apiconfig";
export function VolunteerTasks() {
  const [tasks, setTasks] = useState<any[]>([]);
  const fetchTasksByVolunteer = async () => {
    const volunteer = JSON.parse(sessionStorage.getItem("volunteer") || "{}");
    const response = await api.get(`volunteer/task/${volunteer.id}`);
    console.log(response.data, "response");
    setTasks(response.data.task);
  };
  useEffect(() => {
    let mounted = true;
    if (mounted) {
      fetchTasksByVolunteer();
    }
    return () => {
      mounted = false;
    };
  }, []);
  return (
    <>
      <Header />
      <div className="container admin">
        <div
          className="h5 text-center"
          style={{
            marginTop: "60px",
          }}
        >
          View Tasks
        </div>
        <div className="card mt-3">
          <div className="card-body">
            <table className="table table-bordered text-center">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Date</th>
                  <th>Name</th>
                  <th>Description</th>
                  <th>File</th>
                  <th>Organization</th>
                  <th>Volunteer</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {tasks.map((task: any, index: number) => (
                  <tr key={task.id}>
                    <td>{index + 1}</td>
                    <td>{task.createdAt}</td>
                    <td>{task.taskName}</td>
                    <td>{task.description}</td>
                    <td>
                      <button
                        className="btn btn-primary"
                        type="button"
                        onClick={async () => {
                          try {
                            const response = await api.get(
                              `task/download/${task.filename}`,
                              {
                                responseType: "blob", // Set response type to 'blob' to handle binary data
                              }
                            );

                            // Create a blob from the response data
                            const blob = new Blob([response.data]);

                            // Create a URL for the blob
                            const url = window.URL.createObjectURL(blob);

                            // Create a link element
                            const link = document.createElement("a");
                            link.href = url;
                            link.setAttribute("download", task.filename); // Set the download attribute

                            // Append the link to the document body and click it
                            document.body.appendChild(link);
                            link.click();

                            // Clean up
                            document.body.removeChild(link);
                            window.URL.revokeObjectURL(url);
                          } catch (error) {
                            toast.error("Failed to download file");
                          }
                        }}
                      >
                        Download
                      </button>
                    </td>
                    <td>{task.organization?.name}</td>
                    <td>{task.volunteer?.name}</td>
                    <td>
                      <button
                        className="btn btn-danger"
                        onClick={async () => {
                          try {
                            await api.delete(`task/${task.id}`);
                            fetchTasksByVolunteer();
                            toast.success("Task deleted successfully");
                          } catch (error) {
                            toast.error("Failed to delete task");
                          }
                        }}
                      >
                        <i className="fa-solid fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <Toaster />
    </>
  );
}
