import "./viewOrganizations.css";
import { Header } from "../header/header";
import { api } from "../../utils/apiconfig";
import { useEffect, useState, useRef } from "react";
import { toast, Toaster } from "react-hot-toast";
export interface Organization {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: string;
}

export function Organizations() {
  const [chat, setChat] = useState<any[]>([]);
  const [selectedOrganization, setSelectedOrganization] = useState<number>(0); // [1
  const message = useRef<HTMLInputElement>(null);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const fetchOrganizations = async () => {
    const response = await api.get("organization");
    // console.log(response.data, "data");
    setOrganizations(response.data.organization);
  };

  const fetchChat = async (reciver: number) => {
    try {
      const volunteer = JSON.parse(
        sessionStorage.getItem("volunteer") as string
      );
      const response = await api.get(`chat/message/${volunteer.id}/${reciver}`);
      console.log(response.data, "chat");
      setChat(response.data.msg);
    } catch (error) {
      toast.error("Failed to fetch chat");
    }
  };

  useEffect(() => {
    let mounted = true;
    if (mounted) {
      fetchOrganizations();
    }
    return () => {
      mounted = false;
    };
  }, []);
  return (
    <>
      <Header />
      <div className="container admin">
        <div
          className="h5 text-center"
          style={{
            marginTop: "60px",
          }}
        >
          View Organizations
        </div>
        <div className="card mt-3">
          <div className="card-body">
            <table className="table table-bordered text-center">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Mobile</th>
                  <th>Address</th>
                  <th>Actions</th>
                  <th>Chat</th>
                </tr>
              </thead>
              <tbody>
                {organizations.map(
                  (organization: Organization, index: number) => (
                    <tr key={organization.id}>
                      <td>{index + 1}</td>
                      <td>{organization.name}</td>
                      <td>{organization.email}</td>
                      <td>{organization.phone}</td>
                      <td>{organization.address}</td>
                      <td>
                        <button
                          className="btn btn-danger"
                          type="button"
                          onClick={async () => {
                            try {
                              await api.delete(
                                `organization/${organization.id}`
                              );
                              toast.success(
                                "Organization deleted successfully"
                              );
                              fetchOrganizations();
                            } catch (error) {
                              toast.error("Failed to delete organization");
                            }
                          }}
                        >
                          <i className="fa-solid fa-trash"></i>
                        </button>
                      </td>
                      <td>
                        <button
                          className="btn btn-secondary"
                          type="button"
                          data-bs-toggle="modal"
                          data-bs-target="#chatModal"
                          onClick={() => {
                            setSelectedOrganization(organization.id);
                            fetchChat(organization.id);
                          }}
                        >
                          <i className="fa-regular fa-comment"></i>
                        </button>
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      {/* chat modal */}
      <div
        className="modal fade"
        id="chatModal"
        tabIndex={-1}
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="exampleModalLabel">
                Chat with Organization
              </h1>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div
              className="modal-body"
              style={{
                height: "400px",
                overflowY: "scroll",
              }}
            >
              {chat.map((msg: any, index: number) => (
                <div
                style={{
                  marginTop: "50px"
                }}
                  key={index}
                  className={
                    msg.sender === selectedOrganization
                      ? "text-start"
                      : "text-end"
                  }
                >
                  <span
                    className={
                      msg.sender === selectedOrganization
                        ? "badge bg-primary"
                        : "badge bg-secondary"
                    }
                  >
                    {msg.sender === selectedOrganization
                      ? "Organization"
                      : "Volunteer"}
                  </span>
                  <p
                  
                    className={
                      msg.sender === selectedOrganization
                        ? "alert alert-primary d-inline"
                        : "alert alert-secondary d-inline"
                    }
                  >
                    {msg.message}
                  </p>
                </div>
              ))}
            </div>
            <div className="modal-footer">
              <input
                ref={message}
                type="text"
                className="form-control"
                placeholder="Message"
              />
              <button
                type="button"
                className="btn btn-primary"
                onClick={async () => {
                  console.log(message.current?.value);
                  const volunteer = JSON.parse(
                    sessionStorage.getItem("volunteer") as string
                  );
                  const dataToSend = {
                    message: message.current?.value,
                    sender: volunteer.id,
                    receiver: selectedOrganization,
                  };
                  try {
                    await api.post("chat", dataToSend);
                    toast.success("Message sent successfully");
                    message.current!.value = "";
                    fetchChat(selectedOrganization);
                  } catch (error) {
                    toast.error("Failed to send message");
                  }
                  // message.current!.value = "";
                }}
              >
                Send
              </button>
            </div>
          </div>
        </div>
      </div>
      <Toaster />
    </>
  );
}
